from .opengolfcoach import *

__doc__ = opengolfcoach.__doc__
if hasattr(opengolfcoach, "__all__"):
    __all__ = opengolfcoach.__all__